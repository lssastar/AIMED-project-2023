AlexNet:
![Alex Net loss](image.png)
![Alex Net auc](image-1.png)